export interface ITask {
    id: number;
    body: string;
    isComplete: boolean;
    date: string;
}